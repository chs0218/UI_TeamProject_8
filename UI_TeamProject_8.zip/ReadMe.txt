게임 인터페이스 8팀 기말과제입니다.
UI_TeamProject_8.exe 파일을 실행하면 시작합니다.